angular.module('myApp.services', [])
  .value('version', '0.0.1');