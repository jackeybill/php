var app = angular.module('myApp', [
  'myApp.services',
  'myApp.directives',
  'myApp.filters',
  'myApp.controllers'
  ]);
