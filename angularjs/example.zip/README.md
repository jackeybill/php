ng-book
=======

The ng-book recipe
